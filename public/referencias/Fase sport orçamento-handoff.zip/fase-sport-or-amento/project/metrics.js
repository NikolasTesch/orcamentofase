/* ============================================================
   FASE ESPORTE — Métricas (dashboard)
   Dados ilustrativos para demonstração.
   ============================================================ */
(function () {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s);
  const rootEl = document.documentElement;

  /* tema */
  const SUN = '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>';
  const MOON = '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>';
  function applyTheme(t) {
    rootEl.setAttribute("data-theme", t);
    $("#themeLabel").textContent = t === "light" ? "Modo escuro" : "Modo claro";
    $("#themeIcon").innerHTML = t === "light" ? MOON : SUN;
    $("#appLogo").src = t === "light" ? "assets/logo-fase-preto.svg" : "assets/logo-fase-branco.svg";
    try { localStorage.setItem("fase-theme", t); } catch (e) {}
  }
  let theme = "dark"; try { theme = localStorage.getItem("fase-theme") || "dark"; } catch (e) {}
  applyTheme(theme);
  $("#themeToggle").addEventListener("click", () => applyTheme(rootEl.getAttribute("data-theme") === "light" ? "dark" : "light"));

  /* dados */
  const months = [{ m: "Dez", v: 248 }, { m: "Jan", v: 196 }, { m: "Fev", v: 271 }, { m: "Mar", v: 243 }, { m: "Abr", v: 289 }, { m: "Mai", v: 312 }];
  const mix = [
    { nm: "Kit Esportivo", v: 34, c: "#AF0608" }, { nm: "Estampa Total", v: 23, c: "#D90429" },
    { nm: "Camisa de Malha", v: 18, c: "#f59e0b" }, { nm: "Abadás", v: 14, c: "#10b981" },
    { nm: "Outros", v: 11, c: "#9ca3af" }
  ];
  const rank = [
    { nm: "Kit Esportivo", v: "62 orç.", pct: 100 }, { nm: "Estampa Total", v: "48 orç.", pct: 77 },
    { nm: "Camisa de Malha", v: "39 orç.", pct: 63 }, { nm: "Abadás", v: "28 orç.", pct: 45 },
    { nm: "Linha Social", v: "19 orç.", pct: 31 }
  ];

  /* barras */
  const max = Math.max(...months.map(m => m.v));
  $("#bars").innerHTML = months.map(m =>
    `<div class="bar-col"><div class="bar" style="height:${(m.v / max * 100).toFixed(1)}%"><span class="bar__val">R$ ${m.v}k</span></div><span class="lbl">${m.m}</span></div>`
  ).join("");

  /* donut */
  const C = 2 * Math.PI * 52;
  let acc = 0;
  const segs = mix.map(s => {
    const dash = s.v / 100 * C;
    const seg = `<circle cx="66" cy="66" r="52" fill="none" stroke="${s.c}" stroke-width="20" stroke-dasharray="${dash} ${C - dash}" stroke-dashoffset="${-acc}" transform="rotate(-90 66 66)" style="transition:stroke-width 200ms"/>`;
    acc += dash; return seg;
  }).join("");
  $("#donut").innerHTML = `<svg width="132" height="132" viewBox="0 0 132 132">${segs}
    <text x="66" y="61" text-anchor="middle" fill="var(--text-primary)" font-family="var(--font-display)" font-weight="800" font-size="22">184</text>
    <text x="66" y="80" text-anchor="middle" fill="var(--text-muted)" font-family="var(--font-mono)" font-size="9">orçamentos</text></svg>`;
  $("#legend").innerHTML = mix.map(s =>
    `<div class="legend__row"><span class="legend__dot" style="background:${s.c}"></span><span class="nm">${s.nm}</span><span class="vl">${s.v}%</span></div>`
  ).join("");

  /* ranking */
  $("#rank").innerHTML = rank.map((r, i) =>
    `<div class="rank__row"><span class="rank__pos">${i + 1}</span>
      <div class="rank__bar-wrap"><div class="rank__nm">${r.nm}<span class="v">${r.v}</span></div>
        <div class="rank__track"><div class="rank__fill" style="width:${r.pct}%"></div></div></div></div>`
  ).join("");
})();
