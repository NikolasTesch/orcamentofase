/* ============================================================
   FASE ESPORTE — Tabela de Preços (editor)
   ============================================================ */
(function () {
  "use strict";
  const D = window.FASE_DATA;
  const $ = (s, r = document) => r.querySelector(s);
  const rootEl = document.documentElement;

  /* tema */
  const SUN = '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>';
  const MOON = '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>';
  function applyTheme(t) {
    rootEl.setAttribute("data-theme", t);
    $("#themeLabel").textContent = t === "light" ? "Modo escuro" : "Modo claro";
    $("#themeIcon").innerHTML = t === "light" ? MOON : SUN;
    $("#appLogo").src = t === "light" ? "assets/logo-fase-preto.svg" : "assets/logo-fase-branco.svg";
    try { localStorage.setItem("fase-theme", t); } catch (e) {}
  }
  let theme = "dark"; try { theme = localStorage.getItem("fase-theme") || "dark"; } catch (e) {}
  applyTheme(theme);
  $("#themeToggle").addEventListener("click", () => applyTheme(rootEl.getAttribute("data-theme") === "light" ? "dark" : "light"));

  const KIND_LABEL = { kit: "Kit", esportivo: "Esportivo", promocional: "Promocional", abada: "Abadá · isento de parceria" };
  let schema = D.editSchema();
  let active = schema[0].catId;
  let dirty = false;

  const side = $("#peSide"), detail = $("#peDetail");

  function buildSide() {
    side.innerHTML = schema.map(c => {
      const fields = c.sections.reduce((n, s) => n + (s.type === "matrix" ? s.rows.length * s.cols.length : s.type === "row" ? s.cols.length : s.items.length), 0);
      return `<button class="pe-cat ${c.catId === active ? "active" : ""}" data-cat="${c.catId}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="${c.icon}"/></svg>
        <span>${c.label}</span><span class="badge">${fields}</span></button>`;
    }).join("");
    side.querySelectorAll(".pe-cat").forEach(b => b.addEventListener("click", () => { active = b.dataset.cat; buildSide(); renderDetail(); }));
  }

  const num = (n) => Number.isInteger(n) ? n : (n + "").replace(".", ",");
  function inputCell(catId, group, pathAttr, val, suffix) {
    const pre = group === "tamM2" ? "" : "R$";
    return `<div class="pe-num">${pre ? `<span class="pre">${pre}</span>` : ""}
      <input class="pe-input" type="text" inputmode="decimal" value="${num(val)}" data-cat="${catId}" data-group="${group}" ${pathAttr}></div>`;
  }

  function renderDetail() {
    const c = schema.find(x => x.catId === active);
    const pb = D.getPB()[c.catId];
    let html = `<div class="pe-cat-title">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" style="width:24px;height:24px;color:var(--fase-red)"><path d="${c.icon}"/></svg>
        <h2>${c.label}</h2><span class="tag tag--partner">${KIND_LABEL[c.kind]}</span></div>`;

    c.sections.forEach(sec => {
      html += `<div class="panel"><div class="pe-section__title">${sec.title}</div>`;
      if (sec.type === "matrix") {
        html += `<div class="pe-section__sub">Valores em R$ por unidade, conforme a faixa de quantidade.</div>`;
        html += `<table class="pe-matrix"><thead><tr><th>Item</th>${sec.cols.map(c2 => `<th>${c2}</th>`).join("")}</tr></thead><tbody>`;
        sec.rows.forEach(row => {
          html += `<tr><td>${row.label}</td>`;
          sec.cols.forEach((_, b) => { html += `<td>${inputCell(c.catId, sec.group, `data-sub="${row.key}" data-bidx="${b}"`, pb[sec.group][row.key][b])}</td>`; });
          html += `</tr>`;
        });
        html += `</tbody></table>`;
      } else if (sec.type === "row") {
        html += `<div class="pe-section__sub">Valor base em R$ por unidade, conforme a faixa de quantidade.</div>`;
        html += `<table class="pe-matrix"><thead><tr><th>Faixa</th>${sec.cols.map(c2 => `<th>${c2}</th>`).join("")}</tr></thead><tbody><tr><td>Preço base</td>`;
        sec.cols.forEach((_, b) => { html += `<td>${inputCell(c.catId, sec.group, `data-bidx="${b}"`, pb[sec.group][b])}</td>`; });
        html += `</tr></tbody></table>`;
      } else {
        html += `<div class="pe-list">`;
        sec.items.forEach(it => {
          html += `<div class="pe-field"><label>${it.label}</label>${inputCell(c.catId, sec.group, `data-sub="${it.key}"`, pb[sec.group][it.key])}</div>`;
        });
        html += `</div>`;
      }
      html += `</div>`;
    });
    detail.innerHTML = html;
  }

  /* edição */
  detail.addEventListener("input", (e) => {
    const inp = e.target.closest(".pe-input"); if (!inp) return;
    const catId = inp.dataset.cat, group = inp.dataset.group;
    const v = inp.value.replace(",", ".");
    if (inp.dataset.bidx !== undefined && inp.dataset.sub !== undefined)
      D.setPrice(catId, group, [inp.dataset.sub, parseInt(inp.dataset.bidx, 10)], v);
    else if (inp.dataset.bidx !== undefined)
      D.setPrice(catId, group, parseInt(inp.dataset.bidx, 10), v);
    else
      D.setPrice(catId, group, inp.dataset.sub, v);
    inp.classList.add("changed");
    dirty = true;
  });

  $("#saveBtn").addEventListener("click", () => {
    D.savePB(); dirty = false;
    detail.querySelectorAll(".pe-input.changed").forEach(i => i.classList.remove("changed"));
    const t = $("#toast"); t.classList.add("show"); setTimeout(() => t.classList.remove("show"), 1900);
  });
  $("#resetBtn").addEventListener("click", () => {
    if (!confirm("Restaurar todos os preços para o padrão da fábrica? As alterações salvas serão perdidas.")) return;
    D.resetPB(); dirty = false; schema = D.editSchema(); renderDetail();
    const t = $("#toast"); t.textContent = "Preços restaurados ao padrão"; t.classList.add("show");
    setTimeout(() => { t.classList.remove("show"); t.textContent = "Alterações salvas"; }, 1900);
  });

  window.addEventListener("beforeunload", (e) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } });

  buildSide();
  renderDetail();
})();
