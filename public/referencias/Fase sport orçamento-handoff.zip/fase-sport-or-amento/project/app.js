/* ============================================================
   FASE ESPORTE — Gerador de Orçamentos · lógica do app
   ============================================================ */
(function () {
  "use strict";
  const D = window.FASE_DATA;
  const $ = (s, r = document) => r.querySelector(s);
  const root = document.documentElement;
  const MESES = ["janeiro","fevereiro","março","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro"];
  const MON = ["JAN","FEV","MAR","ABR","MAI","JUN","JUL","AGO","SET","OUT","NOV","DEZ"];

  /* ---------- estado ---------- */
  const state = {
    activeCat: D.CATEGORIES[0].id,
    config: {},
    cart: [],
    client: { name: "", phone: "", partnership: "Nenhuma" },
    disc: { type: "percentage", value: 0 },
    cond: { delivery: 30, validity: 7 }
  };
  D.CATEGORIES.forEach(c => { state.config[c.id] = Object.assign({ qty: c.brackets ? 100 : 12 }, JSON.parse(JSON.stringify(c.defaults))); });
  const getCat = (id) => D.CATEGORIES.find(c => c.id === id);
  const curCat = () => getCat(state.activeCat);
  const curSt  = () => state.config[state.activeCat];
  const computeUnit = (cat, st) => Math.max(0, cat.price(st, cat.brackets ? D.bracketIndex(st.qty || 0) : null));

  /* ---------- tema ---------- */
  const SUN = '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>';
  const MOON = '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>';
  function applyTheme(t) {
    root.setAttribute("data-theme", t);
    $("#themeLabel").textContent = t === "light" ? "Modo escuro" : "Modo claro";
    $("#themeIcon").innerHTML = t === "light" ? MOON : SUN;
    $("#appLogo").src = t === "light" ? "assets/logo-fase-preto.svg" : "assets/logo-fase-branco.svg";
    try { localStorage.setItem("fase-theme", t); } catch (e) {}
  }
  let theme = "dark"; try { theme = localStorage.getItem("fase-theme") || "dark"; } catch (e) {}
  applyTheme(theme);
  $("#themeToggle").addEventListener("click", () => applyTheme(root.getAttribute("data-theme") === "light" ? "dark" : "light"));

  /* ---------- abas ---------- */
  const tabsEl = $("#catTabs");
  const indicator = document.createElement("div");
  indicator.className = "tab-indicator";
  indicator.style.position = "absolute";
  tabsEl.style.position = "relative";
  const TRANS = "transform 380ms cubic-bezier(0.34,1.56,0.64,1), width 380ms cubic-bezier(0.34,1.56,0.64,1), height 380ms";
  function buildTabs() {
    tabsEl.innerHTML = D.CATEGORIES.map(c =>
      `<button class="tab-btn ${c.id === state.activeCat ? "active" : ""}" data-cat="${c.id}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="${c.icon}"/></svg><span>${c.label}</span></button>`).join("");
    tabsEl.prepend(indicator);
    tabsEl.querySelectorAll(".tab-btn").forEach(b => b.addEventListener("click", () => setCat(b.dataset.cat)));
  }
  function moveIndicator(btn) {
    if (!btn) return;
    indicator.style.width = btn.offsetWidth + "px";
    indicator.style.height = btn.offsetHeight + "px";
    indicator.style.transform = `translate(${btn.offsetLeft - 5}px, ${btn.offsetTop - 5}px)`;
  }
  function placeIndicator() {
    const a = tabsEl.querySelector(".tab-btn.active");
    indicator.style.transition = "none"; moveIndicator(a);
    requestAnimationFrame(() => { indicator.style.transition = TRANS; });
  }
  function setCat(id) {
    state.activeCat = id;
    tabsEl.querySelectorAll(".tab-btn").forEach(b => b.classList.toggle("active", b.dataset.cat === id));
    moveIndicator(tabsEl.querySelector(".tab-btn.active"));
    renderConfigurator(true);
  }

  /* ---------- configurador ---------- */
  const cfg = $("#configurator");
  const simWrap = $("#simWrap");
  function optBtns(sel, st, catId) {
    return sel.options.map(o => {
      const on = sel.type === "radio" ? st[sel.key] === o.v : (st[sel.key] || []).includes(o.v);
      const meta = D.metaFor(catId, sel.key, o.v);
      return `<button class="btn-option ${sel.type} ${on ? "selected" : ""}" data-key="${sel.key}" data-v="${o.v}">
        <span class="btn-option__check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6 9 17l-5-5"/></svg></span>
        <span class="btn-option__label">${o.label}</span>
        ${meta ? `<span class="btn-option__meta">${meta}</span>` : ""}
      </button>`;
    }).join("");
  }
  function renderConfigurator(animateIn) {
    const cat = curCat(), st = curSt();
    const bLabel = cat.brackets ? `<span class="bracket">Faixa <b id="brkLabel">${D.BRACKETS[D.bracketIndex(st.qty)].label}</b> un</span>` : "";
    let html = `<div class="config-head"><h2>${cat.label}</h2>${bLabel}</div>`;
    cat.selectors.forEach(sel => {
      html += `<div class="sel-group"><p class="sel-group__label">${sel.label}${sel.type === "check" ? " · múltipla" : ""}</p><div class="opt-grid">${optBtns(sel, st, cat.id)}</div></div>`;
    });
    html += `<div class="sel-group"><p class="sel-group__label">Quantidade</p><div class="qty-block"><div>
        <div class="qty ${st.qty < 10 ? "warn" : ""}" id="qtyEl"><button data-step="-10">−</button><input id="qtyInput" type="text" inputmode="numeric" value="${st.qty}"><button data-step="10">+</button></div>
        <div class="qty-warn-text" id="qtyWarn" style="${st.qty < 10 ? "" : "visibility:hidden"}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h0"/></svg>Abaixo do mínimo sugerido (10)</div>
      </div></div></div>`;
    cfg.innerHTML = html;
    if (animateIn) { cfg.style.animation = "none"; void cfg.offsetWidth; cfg.style.animation = "rowIn 260ms var(--ease-out)"; }
    renderSimulator(true);
  }
  function renderSimulator(flash) {
    const cat = curCat(), st = curSt();
    const unit = computeUnit(cat, st);
    simWrap.innerHTML = `<div class="simulator">
      <div class="simulator__info">
        <div class="simulator__price-label">Preço unitário estimado</div>
        <div class="simulator__price ${flash ? "flash" : ""}">${D.fmtBRL(unit)} <small>/ un · ${st.qty} un</small></div>
        <div class="simulator__desc">${cat.describe(st)}</div>
      </div>
      <button class="btn btn--primary btn--lg" id="addBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5v14"/></svg>Adicionar</button>
    </div>`;
    $("#addBtn").addEventListener("click", addToCart);
  }
  cfg.addEventListener("click", (e) => {
    const opt = e.target.closest(".btn-option");
    if (opt) {
      const st = curSt(), k = opt.dataset.key, v = opt.dataset.v;
      const sel = curCat().selectors.find(s => s.key === k);
      if (sel.type === "radio") st[k] = v;
      else { const arr = st[k] || (st[k] = []); const i = arr.indexOf(v); i < 0 ? arr.push(v) : arr.splice(i, 1); }
      renderConfigurator(); return;
    }
    const q = e.target.closest(".qty button");
    if (q) { const st = curSt(); st.qty = Math.max(0, (st.qty || 0) + parseInt(q.dataset.step, 10)); renderConfigurator(); }
  });
  cfg.addEventListener("input", (e) => {
    if (e.target.id !== "qtyInput") return;
    const st = curSt(); st.qty = parseInt(e.target.value, 10) || 0;
    const warn = st.qty < 10;
    $("#qtyEl").classList.toggle("warn", warn);
    $("#qtyWarn").style.visibility = warn ? "visible" : "hidden";
    if (curCat().brackets) $("#brkLabel").textContent = D.BRACKETS[D.bracketIndex(st.qty)].label;
    renderSimulator(false);
  });

  function addToCart() {
    const cat = curCat(), st = curSt();
    if (!st.qty) return;
    state.cart.push({ uid: Date.now() + "" + Math.random().toString(36).slice(2, 6), catId: cat.id, kind: cat.kind, desc: cat.describe(st), qty: st.qty, unit: computeUnit(cat, st), snap: JSON.parse(JSON.stringify(st)) });
    renderCart(); renderTotals();
    if (window.matchMedia("(max-width:1024px)").matches) openDrawer(true);
  }

  /* ---------- carrinho ---------- */
  const cartList = $("#cartList");
  function partnerInfo(it) {
    const d = D.partnerDiscount(state.client.partnership, it.kind);
    if (state.client.partnership !== "Nenhuma" && it.kind === "abada")
      return { tag: `<span class="tag tag--exempt"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>Isento de desconto</span>`, d: 0 };
    if (d > 0) {
      const short = state.client.partnership.split(" ")[0];
      return { tag: `<span class="tag tag--discount"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6 9 17l-5-5"/></svg>${short} −${d}%</span>`, d };
    }
    return { tag: "", d: 0 };
  }
  function renderCart() {
    $("#cartCount").textContent = state.cart.length + (state.cart.length === 1 ? " item" : " itens");
    $("#fabBadge").textContent = state.cart.length;
    if (!state.cart.length) {
      cartList.innerHTML = `<div class="cart-empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6 6h15l-1.5 9h-12L6 6Zm0 0L5 3H2"/><circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/></svg>Nenhum item adicionado.<br>Configure uma peça e clique em <b>Adicionar</b>.</div>`;
      return;
    }
    cartList.innerHTML = state.cart.map(it => {
      const info = partnerInfo(it);
      const gross = it.unit * it.qty;
      const net = gross * (1 - info.d / 100);
      return `<div class="cart-row" data-uid="${it.uid}">
        <div class="cart-row__mini"><button data-act="dec">−</button><input data-act="qty" value="${it.qty}"><button data-act="inc">+</button></div>
        <div><div class="cart-row__desc">${it.desc}</div><div class="cart-row__sub">${D.fmtBRL(it.unit)} un ${info.tag}</div></div>
        <div class="cart-row__total">${D.fmtBRL(net)}${info.d ? `<del>${D.fmtBRL(gross)}</del>` : ""}</div>
        <button class="icon-btn icon-btn--danger" data-act="del"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg></button>
      </div>`;
    }).join("");
  }
  cartList.addEventListener("click", (e) => {
    const row = e.target.closest(".cart-row"); if (!row) return;
    const it = state.cart.find(x => x.uid === row.dataset.uid); if (!it) return;
    const act = e.target.closest("[data-act]") && e.target.closest("[data-act]").dataset.act;
    if (act === "del") { row.style.animation = "rowIn 200ms reverse"; setTimeout(() => { state.cart = state.cart.filter(x => x !== it); renderCart(); renderTotals(); }, 150); }
    else if (act === "inc") { it.qty += 10; refreshCartRow(it); }
    else if (act === "dec") { it.qty = Math.max(1, it.qty - 10); refreshCartRow(it); }
  });
  cartList.addEventListener("input", (e) => {
    if (e.target.dataset.act !== "qty") return;
    const row = e.target.closest(".cart-row");
    const it = state.cart.find(x => x.uid === row.dataset.uid); if (!it) return;
    it.qty = parseInt(e.target.value, 10) || 1;
    // re-price bracketed items live
    repriceItem(it); renderTotals();
    row.querySelector(".cart-row__total").innerHTML = totalCell(it);
    row.querySelector(".cart-row__sub").innerHTML = `${D.fmtBRL(it.unit)} un ${partnerInfo(it).tag}`;
  });
  function repriceItem(it) {
    const cat = getCat(it.catId);
    if (!cat.brackets || !it.snap) return;   // só itens com faixa de volume mudam de preço
    it.snap.qty = it.qty;
    it.unit = computeUnit(cat, it.snap);
  }
  function refreshCartRow(it) { repriceItem(it); renderCart(); renderTotals(); }
  function totalCell(it) {
    const info = partnerInfo(it); const gross = it.unit * it.qty; const net = gross * (1 - info.d / 100);
    return `${D.fmtBRL(net)}${info.d ? `<del>${D.fmtBRL(gross)}</del>` : ""}`;
  }

  /* ---------- totais ---------- */
  function renderTotals() {
    let sub = 0, partnerDisc = 0, hasAbadaExempt = false;
    state.cart.forEach(it => {
      const line = it.unit * it.qty; sub += line;
      const d = D.partnerDiscount(state.client.partnership, it.kind);
      partnerDisc += line * d / 100;
      if (state.client.partnership !== "Nenhuma" && it.kind === "abada") hasAbadaExempt = true;
    });
    const afterPartner = sub - partnerDisc;
    let add = 0;
    if (state.disc.type === "percentage") add = afterPartner * (Math.min(100, state.disc.value) / 100);
    else add = Math.min(state.disc.value, afterPartner);
    const net = Math.max(0, afterPartner - add);
    const entry = net * 0.5;
    $("#tSub").textContent = D.fmtBRL(sub);
    $("#tPartner").textContent = (partnerDisc > 0 ? "− " : "") + D.fmtBRL(partnerDisc);
    $("#tAdd").textContent = (add > 0 ? "− " : "") + D.fmtBRL(add);
    $("#tNet").textContent = D.fmtBRL(net);
    $("#tEntry").textContent = D.fmtBRL(entry);

    const note = $("#partnerNote");
    let noteHtml = "";
    if (state.client.partnership !== "Nenhuma" && partnerDisc > 0)
      noteHtml += `<div class="alert alert--partner"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M12 2 2 7l10 5 10-5-10-5Z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/></svg><span><b>*INCLUSA LOGO DA FASE</b> na frente e costas em destaque (obrigatório para parceria, exceto formandos).</span></div>`;
    if (hasAbadaExempt)
      noteHtml += `<div class="alert alert--warning" style="margin-top:8px"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><span>Abadá isento de desconto de parceria (regra de evento).</span></div>`;
    note.innerHTML = noteHtml; note.style.display = noteHtml ? "block" : "none";

    state._calc = { sub, partnerDisc, add, net, entry };
  }

  /* ---------- formulário ---------- */
  const partSel = $("#partnership");
  partSel.innerHTML = Object.keys(D.PARTNERS).map(k => `<option ${k === "Nenhuma" ? "selected" : ""}>${k}</option>`).join("");
  partSel.addEventListener("change", () => { state.client.partnership = partSel.value; renderCart(); renderTotals(); });
  $("#clientName").addEventListener("input", e => state.client.name = e.target.value);
  $("#clientPhone").addEventListener("input", e => state.client.phone = e.target.value);
  $("#discValue").addEventListener("input", e => { state.disc.value = parseFloat(e.target.value) || 0; renderTotals(); });
  $("#discType").addEventListener("click", e => {
    const b = e.target.closest("button"); if (!b) return;
    $("#discType").querySelectorAll("button").forEach(x => x.classList.remove("active"));
    b.classList.add("active"); state.disc.type = b.dataset.t; renderTotals();
  });
  $("#delivery").addEventListener("input", e => state.cond.delivery = parseInt(e.target.value, 10) || 0);
  $("#validity").addEventListener("input", e => state.cond.validity = parseInt(e.target.value, 10) || 0);

  $("#clearBtn").addEventListener("click", () => {
    if (!state.cart.length || confirm("Limpar todos os itens do orçamento?")) { state.cart = []; renderCart(); renderTotals(); }
  });

  /* ---------- folha A4 ---------- */
  function updateSheet() {
    const c = state._calc || { sub: 0, partnerDisc: 0, add: 0, net: 0, entry: 0 };
    const now = new Date();
    $("#a4Client").textContent = state.client.name || "—";
    $("#a4Phone").textContent = state.client.phone || "—";
    $("#a4Date").textContent = `Teixeira de Freitas — BA, ${now.getDate()} de ${MESES[now.getMonth()]} de ${now.getFullYear()}`;
    $("#a4Num").textContent = `Nº 0142 · ${String(now.getDate()).padStart(2,"0")} ${MON[now.getMonth()]} ${now.getFullYear()}`;
    $("#a4Delivery").textContent = state.cond.delivery;
    $("#a4Validity").textContent = String(state.cond.validity).padStart(2, "0");
    $("#a4Rows").innerHTML = state.cart.length ? state.cart.map(it =>
      `<tr><td>${it.qty}</td><td>${it.desc}</td><td class="ar">${(it.unit).toFixed(2).replace(".",",")}</td><td class="ar">${(it.unit*it.qty).toFixed(2).replace(".",",")}</td></tr>`
    ).join("") : `<tr><td colspan="4" style="text-align:center;color:#999 !important;padding:18px">Nenhum item no orçamento.</td></tr>`;
    $("#a4Total").textContent = D.fmtBRL(c.sub);
    $("#a4DiscLine").textContent = "− " + D.fmtBRL(c.partnerDisc + c.add);
    $("#a4Net").textContent = D.fmtBRL(c.net);
    $("#a4Entry").textContent = D.fmtBRL(c.entry);
    const pn = $("#a4PartnerNote");
    pn.innerHTML = (state.client.partnership !== "Nenhuma" && c.partnerDisc > 0)
      ? "*INCLUSA LOGO DA FASE NA FRENTE E COSTAS EM DESTAQUE, EXCETO CAMISAS DE FORMANDOS." : "";
  }

  /* ---------- modal / impressão ---------- */
  const modal = $("#modal"), sheetWrap = $("#sheetWrap"), a4 = $("#a4");
  function sheetHome() { if (a4.parentElement !== sheetWrap) sheetWrap.appendChild(a4); }
  function openModal() { updateSheet(); $("#modalMount").appendChild(a4); modal.classList.add("open"); }
  function closeModal() { modal.classList.remove("open"); sheetHome(); }
  $("#previewBtn").addEventListener("click", openModal);
  $("#modalClose").addEventListener("click", closeModal);
  modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });
  function doPrint() { updateSheet(); closeModal(); sheetHome(); setTimeout(() => window.print(), 60); }
  $("#printBtn").addEventListener("click", doPrint);
  $("#modalPrint").addEventListener("click", doPrint);

  /* ---------- WhatsApp ---------- */
  $("#waBtn").addEventListener("click", () => {
    const c = state._calc || {};
    let t = `*ORÇAMENTO FASE ESPORTE*\n`;
    if (state.client.name) t += `Cliente: ${state.client.name}\n`;
    t += `\n`;
    state.cart.forEach(it => { t += `• ${it.qty}x ${it.desc} — ${D.fmtBRL(it.unit * it.qty)}\n`; });
    t += `\n*Total líquido:* ${D.fmtBRL(c.net || 0)}\n*Entrada (50%):* ${D.fmtBRL(c.entry || 0)}\n`;
    t += `Entrega: ${state.cond.delivery} dias · Validade: ${state.cond.validity} dias`;
    const phone = (state.client.phone || "").replace(/\D/g, "");
    window.open(`https://wa.me/${phone ? "55" + phone : ""}?text=${encodeURIComponent(t)}`, "_blank");
  });

  /* ---------- drawer mobile ---------- */
  const app = $("#app");
  function openDrawer(o) { app.classList.toggle("drawer-open", o); }
  $("#cartFab").addEventListener("click", () => openDrawer(true));
  $("#drawerClose").addEventListener("click", () => openDrawer(false));
  $("#drawerBackdrop").addEventListener("click", () => openDrawer(false));

  /* ---------- init ---------- */
  buildTabs();
  renderConfigurator();
  renderCart();
  renderTotals();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(placeIndicator);
  window.addEventListener("load", placeIndicator);
  requestAnimationFrame(placeIndicator);
})();
