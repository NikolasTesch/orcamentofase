/* ============================================================
   FASE ESPORTE — Design System (guia vivo)
   ============================================================ */
(function () {
  "use strict";
  const root = document.documentElement;

  /* ---------- Tema ---------- */
  const themeBtn   = document.getElementById("themeToggle");
  const themeLabel = document.getElementById("themeLabel");
  const themeIcon  = document.getElementById("themeIcon");
  const SUN = '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>';
  const MOON = '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>';

  function swapLogos(theme) {
    const src = theme === "light" ? "assets/logo-fase-preto.svg" : "assets/logo-fase-branco.svg";
    document.querySelectorAll("#navLogo, .logo-themed").forEach(img => { img.src = src; });
  }
  function applyTheme(theme) {
    root.setAttribute("data-theme", theme);
    themeLabel.textContent = theme === "light" ? "Modo escuro" : "Modo claro";
    themeIcon.innerHTML = theme === "light" ? MOON : SUN;
    swapLogos(theme);
    try { localStorage.setItem("fase-theme", theme); } catch (e) {}
  }
  let theme = "dark";
  try { theme = localStorage.getItem("fase-theme") || "dark"; } catch (e) {}
  applyTheme(theme);
  themeBtn.addEventListener("click", () => {
    theme = root.getAttribute("data-theme") === "light" ? "dark" : "light";
    applyTheme(theme);
  });

  /* ---------- Acento (cor de marca) ---------- */
  const accentMap = {
    "#AF0608": "#D90429",
    "#D90429": "#F11D3B",
    "#E11D48": "#F43F5E"
  };
  document.querySelectorAll(".accent-dot").forEach(dot => {
    dot.addEventListener("click", () => {
      const c = dot.dataset.c;
      root.style.setProperty("--fase-red", c);
      root.style.setProperty("--fase-red-hover", accentMap[c] || c);
      const rgb = c.match(/\w\w/g).map(h => parseInt(h, 16));
      root.style.setProperty("--fase-red-12", `rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.12)`);
      root.style.setProperty("--fase-red-15", `rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.15)`);
      root.style.setProperty("--fase-red-glow", `rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.35)`);
      root.style.setProperty("--border-color-active", `rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.6)`);
      root.style.setProperty("--shadow-glow", `0 0 15px rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.35)`);
      root.style.setProperty("--shadow-glow-soft", `0 0 10px rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.15)`);
      document.querySelectorAll(".accent-dot").forEach(d => d.style.outline = "none");
      dot.style.outline = "2px solid var(--text-primary)";
      dot.style.outlineOffset = "2px";
    });
  });

  /* ---------- Escala de espaçamento ---------- */
  const spaces = [["--space-1",4],["--space-2",8],["--space-3",12],["--space-4",16],["--space-5",20],["--space-6",24],["--space-8",32],["--space-10",40],["--space-12",48],["--space-16",64]];
  const spaceList = document.getElementById("spaceList");
  if (spaceList) {
    spaceList.innerHTML = spaces.map(([t,v]) =>
      `<div class="token-list__row"><code>${t}</code><span class="val">${v}px</span><div class="space-bar" style="width:${v}px"></div></div>`
    ).join("");
  }

  /* ---------- Abas — indicador líquido ---------- */
  const tabs = document.getElementById("tabsDemo");
  if (tabs) {
    const indicator = document.createElement("div");
    indicator.className = "tab-indicator";
    function moveIndicator(btn) {
      indicator.style.width = btn.offsetWidth + "px";
      indicator.style.height = btn.offsetHeight + "px";
      indicator.style.transform = `translate(${btn.offsetLeft - 5}px, ${btn.offsetTop - 5}px)`;
    }
    tabs.style.position = "relative";
    indicator.style.position = "absolute";
    tabs.prepend(indicator);
    const TRANSITION = "transform 380ms cubic-bezier(0.34,1.56,0.64,1), width 380ms cubic-bezier(0.34,1.56,0.64,1), height 380ms";
    const active = tabs.querySelector(".tab-btn.active");
    function initIndicator() {
      if (!active) return;
      indicator.style.transition = "none";   // place instantly, no 0→width animation
      moveIndicator(active);
      requestAnimationFrame(() => { indicator.style.transition = TRANSITION; }); // enable for clicks
    }
    requestAnimationFrame(initIndicator);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(initIndicator);
    window.addEventListener("load", initIndicator);
    window.addEventListener("resize", () => moveIndicator(tabs.querySelector(".tab-btn.active")));
    tabs.querySelectorAll(".tab-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        tabs.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        moveIndicator(btn);
      });
    });
  }

  /* ---------- Botões de opção ---------- */
  document.querySelectorAll('[data-group]').forEach(group => {
    const isRadio = group.dataset.group === "radio";
    group.querySelectorAll(".btn-option").forEach(opt => {
      opt.addEventListener("click", () => {
        if (isRadio) {
          group.querySelectorAll(".btn-option").forEach(o => o.classList.remove("selected"));
          opt.classList.add("selected");
        } else {
          opt.classList.toggle("selected");
        }
      });
    });
  });

  /* ---------- Seletor de quantidade ---------- */
  document.querySelectorAll(".qty").forEach(qty => {
    const input = qty.querySelector("input");
    qty.querySelectorAll("button").forEach(b => {
      b.addEventListener("click", () => {
        let v = parseInt(input.value, 10) || 0;
        v = Math.max(0, v + parseInt(b.dataset.step, 10));
        input.value = v;
        qty.classList.toggle("warn", v < 10);
        const warnText = qty.parentElement.querySelector(".qty-warn-text");
        if (warnText && !warnText.textContent.includes("ok")) {
          warnText.style.visibility = v < 10 ? "visible" : "hidden";
        }
      });
    });
  });

  /* ---------- Demos de movimento ---------- */
  const tap = document.getElementById("mTap");
  if (tap) {
    tap.style.transition = "transform 150ms cubic-bezier(0.34,1.56,0.64,1)";
    const stage = tap.closest(".motion-card");
    stage.addEventListener("mouseenter", () => tap.style.transform = "scale(1.18)");
    stage.addEventListener("mouseleave", () => tap.style.transform = "scale(1)");
    stage.addEventListener("mousedown", () => tap.style.transform = "scale(0.95)");
    stage.addEventListener("mouseup", () => tap.style.transform = "scale(1.18)");
  }
  const slideA = document.getElementById("mSlideA"), slideB = document.getElementById("mSlideB");
  if (slideA) {
    [slideA, slideB].forEach(d => d.style.transition = "opacity 380ms ease");
    let on = true;
    slideA.closest(".motion-card").addEventListener("mouseenter", () => {
      on = !on;
      slideA.style.opacity = on ? "1" : ".25";
      slideB.style.opacity = on ? ".25" : "1";
    });
  }
  const enter = document.getElementById("mEnter");
  if (enter) {
    enter.style.transition = "transform 400ms cubic-bezier(0.16,1,0.3,1), opacity 300ms";
    const card = enter.closest(".motion-card");
    card.addEventListener("mouseenter", () => {
      enter.style.transform = "translateX(-34px)"; enter.style.opacity = "0";
      requestAnimationFrame(() => { enter.style.transform = "translateX(0)"; enter.style.opacity = "1"; });
    });
  }
  const glow = document.getElementById("mGlow");
  if (glow) {
    glow.style.transition = "box-shadow 300ms ease, border-color 300ms ease";
    glow.style.border = "2px solid transparent";
    const card = glow.closest(".motion-card");
    card.addEventListener("mouseenter", () => { glow.style.boxShadow = "0 0 22px var(--fase-red-glow)"; glow.style.borderColor = "#fff"; });
    card.addEventListener("mouseleave", () => { glow.style.boxShadow = "var(--shadow-glow-soft)"; glow.style.borderColor = "transparent"; });
  }

  /* ---------- Scrollspy ---------- */
  const navLinks = [...document.querySelectorAll(".nav a")];
  const sections = navLinks.map(a => document.querySelector(a.getAttribute("href"))).filter(Boolean);
  const spy = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        navLinks.forEach(a => a.classList.toggle("active", a.getAttribute("href") === "#" + e.target.id));
      }
    });
  }, { rootMargin: "-30% 0px -60% 0px" });
  sections.forEach(s => spy.observe(s));
  navLinks.forEach(a => a.addEventListener("click", e => {
    e.preventDefault();
    const t = document.querySelector(a.getAttribute("href"));
    if (t) window.scrollTo({ top: t.offsetTop - 60, behavior: "smooth" });
  }));
})();
